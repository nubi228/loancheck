#!/bin/bash

docker run \
  --net=host \
  --rm \
  confluentinc/cp-kafka:latest \
  kafka-console-consumer --bootstrap-server localhost:29092 --topic test1 --from-beginning
