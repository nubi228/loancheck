#!/bin/bash

docker run \
  --net=host \
  --rm confluentinc/cp-kafka:latest \
  kafka-topics --create --topic topic1 --partitions 1 --replication-factor 1 --if-not-exists --zookeeper localhost:32181