#!/bin/bash

docker run \
  --net=host \
  --rm \
  confluentinc/cp-kafka:latest \
  bash -c "kafka-console-producer --broker-list localhost:29092 --topic topic1 < $1"



#  bash -c "seq 42 | kafka-console-producer --request-required-acks 1 --broker-list localhost:29092 --topic topic1 && echo 'Produced 42 messages.'"